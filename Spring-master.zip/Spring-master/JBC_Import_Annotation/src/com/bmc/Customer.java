package com.bmc;

public class Customer {
	
	public void printMsg(String msg) {
		 
		System.out.println("Customer : " + msg);
	}

}
