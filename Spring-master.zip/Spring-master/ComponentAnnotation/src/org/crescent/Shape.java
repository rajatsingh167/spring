package org.crescent;

public interface Shape {
	
	void draw();

}
